gdjs.GameCode = {};
gdjs.GameCode.localVariables = [];
gdjs.GameCode.GDCenterObjects1_1final = [];

gdjs.GameCode.GDEnemyBulletObjects1_1final = [];

gdjs.GameCode.GDGhostEnemyObjects1_1final = [];

gdjs.GameCode.GDImpEnemyObjects1_1final = [];

gdjs.GameCode.GDSpiderEnemyObjects1_1final = [];

gdjs.GameCode.forEachCount0_3 = 0;

gdjs.GameCode.forEachCount1_3 = 0;

gdjs.GameCode.forEachCount2_3 = 0;

gdjs.GameCode.forEachIndex3 = 0;

gdjs.GameCode.forEachObjects3 = [];

gdjs.GameCode.forEachTotalCount3 = 0;

gdjs.GameCode.GDFloorObjects1= [];
gdjs.GameCode.GDFloorObjects2= [];
gdjs.GameCode.GDFloorObjects3= [];
gdjs.GameCode.GDFloorObjects4= [];
gdjs.GameCode.GDFloorObjects5= [];
gdjs.GameCode.GDPlayerObjects1= [];
gdjs.GameCode.GDPlayerObjects2= [];
gdjs.GameCode.GDPlayerObjects3= [];
gdjs.GameCode.GDPlayerObjects4= [];
gdjs.GameCode.GDPlayerObjects5= [];
gdjs.GameCode.GDGunObjects1= [];
gdjs.GameCode.GDGunObjects2= [];
gdjs.GameCode.GDGunObjects3= [];
gdjs.GameCode.GDGunObjects4= [];
gdjs.GameCode.GDGunObjects5= [];
gdjs.GameCode.GDBulletObjects1= [];
gdjs.GameCode.GDBulletObjects2= [];
gdjs.GameCode.GDBulletObjects3= [];
gdjs.GameCode.GDBulletObjects4= [];
gdjs.GameCode.GDBulletObjects5= [];
gdjs.GameCode.GDGhostEnemyObjects1= [];
gdjs.GameCode.GDGhostEnemyObjects2= [];
gdjs.GameCode.GDGhostEnemyObjects3= [];
gdjs.GameCode.GDGhostEnemyObjects4= [];
gdjs.GameCode.GDGhostEnemyObjects5= [];
gdjs.GameCode.GDSpiderEnemyObjects1= [];
gdjs.GameCode.GDSpiderEnemyObjects2= [];
gdjs.GameCode.GDSpiderEnemyObjects3= [];
gdjs.GameCode.GDSpiderEnemyObjects4= [];
gdjs.GameCode.GDSpiderEnemyObjects5= [];
gdjs.GameCode.GDImpEnemyObjects1= [];
gdjs.GameCode.GDImpEnemyObjects2= [];
gdjs.GameCode.GDImpEnemyObjects3= [];
gdjs.GameCode.GDImpEnemyObjects4= [];
gdjs.GameCode.GDImpEnemyObjects5= [];
gdjs.GameCode.GDCenterObjects1= [];
gdjs.GameCode.GDCenterObjects2= [];
gdjs.GameCode.GDCenterObjects3= [];
gdjs.GameCode.GDCenterObjects4= [];
gdjs.GameCode.GDCenterObjects5= [];
gdjs.GameCode.GDSpawnPointsObjects1= [];
gdjs.GameCode.GDSpawnPointsObjects2= [];
gdjs.GameCode.GDSpawnPointsObjects3= [];
gdjs.GameCode.GDSpawnPointsObjects4= [];
gdjs.GameCode.GDSpawnPointsObjects5= [];
gdjs.GameCode.GDSpiderSpawnPointsObjects1= [];
gdjs.GameCode.GDSpiderSpawnPointsObjects2= [];
gdjs.GameCode.GDSpiderSpawnPointsObjects3= [];
gdjs.GameCode.GDSpiderSpawnPointsObjects4= [];
gdjs.GameCode.GDSpiderSpawnPointsObjects5= [];
gdjs.GameCode.GDHealthBar_9595EnemyObjects1= [];
gdjs.GameCode.GDHealthBar_9595EnemyObjects2= [];
gdjs.GameCode.GDHealthBar_9595EnemyObjects3= [];
gdjs.GameCode.GDHealthBar_9595EnemyObjects4= [];
gdjs.GameCode.GDHealthBar_9595EnemyObjects5= [];
gdjs.GameCode.GDWallCollisionObjects1= [];
gdjs.GameCode.GDWallCollisionObjects2= [];
gdjs.GameCode.GDWallCollisionObjects3= [];
gdjs.GameCode.GDWallCollisionObjects4= [];
gdjs.GameCode.GDWallCollisionObjects5= [];
gdjs.GameCode.GDvignetteObjects1= [];
gdjs.GameCode.GDvignetteObjects2= [];
gdjs.GameCode.GDvignetteObjects3= [];
gdjs.GameCode.GDvignetteObjects4= [];
gdjs.GameCode.GDvignetteObjects5= [];
gdjs.GameCode.GDRedFlatBarObjects1= [];
gdjs.GameCode.GDRedFlatBarObjects2= [];
gdjs.GameCode.GDRedFlatBarObjects3= [];
gdjs.GameCode.GDRedFlatBarObjects4= [];
gdjs.GameCode.GDRedFlatBarObjects5= [];
gdjs.GameCode.GDEXP_9595PointObjects1= [];
gdjs.GameCode.GDEXP_9595PointObjects2= [];
gdjs.GameCode.GDEXP_9595PointObjects3= [];
gdjs.GameCode.GDEXP_9595PointObjects4= [];
gdjs.GameCode.GDEXP_9595PointObjects5= [];
gdjs.GameCode.GDStatsLabelObjects1= [];
gdjs.GameCode.GDStatsLabelObjects2= [];
gdjs.GameCode.GDStatsLabelObjects3= [];
gdjs.GameCode.GDStatsLabelObjects4= [];
gdjs.GameCode.GDStatsLabelObjects5= [];
gdjs.GameCode.GDPowerButtonObjects1= [];
gdjs.GameCode.GDPowerButtonObjects2= [];
gdjs.GameCode.GDPowerButtonObjects3= [];
gdjs.GameCode.GDPowerButtonObjects4= [];
gdjs.GameCode.GDPowerButtonObjects5= [];
gdjs.GameCode.GDFireRateButtonObjects1= [];
gdjs.GameCode.GDFireRateButtonObjects2= [];
gdjs.GameCode.GDFireRateButtonObjects3= [];
gdjs.GameCode.GDFireRateButtonObjects4= [];
gdjs.GameCode.GDFireRateButtonObjects5= [];
gdjs.GameCode.GDAccuracyButtonObjects1= [];
gdjs.GameCode.GDAccuracyButtonObjects2= [];
gdjs.GameCode.GDAccuracyButtonObjects3= [];
gdjs.GameCode.GDAccuracyButtonObjects4= [];
gdjs.GameCode.GDAccuracyButtonObjects5= [];
gdjs.GameCode.GDWaveNumberObjects1= [];
gdjs.GameCode.GDWaveNumberObjects2= [];
gdjs.GameCode.GDWaveNumberObjects3= [];
gdjs.GameCode.GDWaveNumberObjects4= [];
gdjs.GameCode.GDWaveNumberObjects5= [];
gdjs.GameCode.GDEnemyBulletObjects1= [];
gdjs.GameCode.GDEnemyBulletObjects2= [];
gdjs.GameCode.GDEnemyBulletObjects3= [];
gdjs.GameCode.GDEnemyBulletObjects4= [];
gdjs.GameCode.GDEnemyBulletObjects5= [];
gdjs.GameCode.GDShadowObjects1= [];
gdjs.GameCode.GDShadowObjects2= [];
gdjs.GameCode.GDShadowObjects3= [];
gdjs.GameCode.GDShadowObjects4= [];
gdjs.GameCode.GDShadowObjects5= [];
gdjs.GameCode.GDDropObjects1= [];
gdjs.GameCode.GDDropObjects2= [];
gdjs.GameCode.GDDropObjects3= [];
gdjs.GameCode.GDDropObjects4= [];
gdjs.GameCode.GDDropObjects5= [];
gdjs.GameCode.GDMovementObjects1= [];
gdjs.GameCode.GDMovementObjects2= [];
gdjs.GameCode.GDMovementObjects3= [];
gdjs.GameCode.GDMovementObjects4= [];
gdjs.GameCode.GDMovementObjects5= [];
gdjs.GameCode.GDAimingObjects1= [];
gdjs.GameCode.GDAimingObjects2= [];
gdjs.GameCode.GDAimingObjects3= [];
gdjs.GameCode.GDAimingObjects4= [];
gdjs.GameCode.GDAimingObjects5= [];
gdjs.GameCode.GDScreenOrientationCheckerObjects1= [];
gdjs.GameCode.GDScreenOrientationCheckerObjects2= [];
gdjs.GameCode.GDScreenOrientationCheckerObjects3= [];
gdjs.GameCode.GDScreenOrientationCheckerObjects4= [];
gdjs.GameCode.GDScreenOrientationCheckerObjects5= [];
gdjs.GameCode.GDTransitionObjects1= [];
gdjs.GameCode.GDTransitionObjects2= [];
gdjs.GameCode.GDTransitionObjects3= [];
gdjs.GameCode.GDTransitionObjects4= [];
gdjs.GameCode.GDTransitionObjects5= [];
gdjs.GameCode.GDDarkenObjects1= [];
gdjs.GameCode.GDDarkenObjects2= [];
gdjs.GameCode.GDDarkenObjects3= [];
gdjs.GameCode.GDDarkenObjects4= [];
gdjs.GameCode.GDDarkenObjects5= [];


gdjs.GameCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Aiming"), gdjs.GameCode.GDAimingObjects1);
gdjs.copyArray(runtimeScene.getObjects("Movement"), gdjs.GameCode.GDMovementObjects1);
{for(var i = 0, len = gdjs.GameCode.GDMovementObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMovementObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameCode.GDAimingObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDAimingObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameCode.GDMovementObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMovementObjects1[i].ActivateControl(false, null);
}
}{for(var i = 0, len = gdjs.GameCode.GDAimingObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDAimingObjects1[i].ActivateControl(false, null);
}
}}

}


};gdjs.GameCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "Touch controls", 0, 0, 0);
}
{ //Subevents
gdjs.GameCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList2 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Floor"), gdjs.GameCode.GDFloorObjects1);
gdjs.copyArray(runtimeScene.getObjects("SpawnPoints"), gdjs.GameCode.GDSpawnPointsObjects1);
gdjs.copyArray(runtimeScene.getObjects("SpiderSpawnPoints"), gdjs.GameCode.GDSpiderSpawnPointsObjects1);
gdjs.copyArray(runtimeScene.getObjects("Transition"), gdjs.GameCode.GDTransitionObjects1);
gdjs.copyArray(runtimeScene.getObjects("WallCollision"), gdjs.GameCode.GDWallCollisionObjects1);
gdjs.copyArray(runtimeScene.getObjects("vignette"), gdjs.GameCode.GDvignetteObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 2, "Vignette", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.GameCode.GDFloorObjects1.length !== 0 ? gdjs.GameCode.GDFloorObjects1[0] : null), true, "", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.GameCode.GDvignetteObjects1.length !== 0 ? gdjs.GameCode.GDvignetteObjects1[0] : null), true, "Vignette", 0);
}{for(var i = 0, len = gdjs.GameCode.GDWallCollisionObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDWallCollisionObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameCode.GDSpiderSpawnPointsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderSpawnPointsObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameCode.GDSpawnPointsObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSpawnPointsObjects1[i].hide();
}
}{gdjs.evtsExt__CameraShake__SetLayerRotationAmplitude.func(runtimeScene, 1, "", null);
}{gdjs.evtsExt__CameraShake__SetDefaultZoomAmplitude.func(runtimeScene, 1, null);
}{gdjs.evtsExt__CameraShake__SetLayerTranslationAmplitude.func(runtimeScene, 1, 1, "", null);
}{gdjs.evtsExt__CameraShake__SetLayerShakingFrequency.func(runtimeScene, 5, "", null);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1.5, "transition", 0);
}{for(var i = 0, len = gdjs.GameCode.GDTransitionObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDTransitionObjects1[i].getBehavior("FlashTransitionPainter").PaintEffect("0;0;0", 1, "Circular", "Backward", 0, null);
}
}
{ //Subevents
gdjs.GameCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMovementObjects1Objects = Hashtable.newFrom({"Movement": gdjs.GameCode.GDMovementObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMovementObjects1Objects = Hashtable.newFrom({"Movement": gdjs.GameCode.GDMovementObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGhostEnemyObjects1Objects = Hashtable.newFrom({"GhostEnemy": gdjs.GameCode.GDGhostEnemyObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSpiderEnemyObjects1Objects = Hashtable.newFrom({"SpiderEnemy": gdjs.GameCode.GDSpiderEnemyObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDImpEnemyObjects1Objects = Hashtable.newFrom({"ImpEnemy": gdjs.GameCode.GDImpEnemyObjects1});
gdjs.GameCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.GameCode.GDBulletObjects1);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.GameCode.GDGhostEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameCode.GDGunObjects1);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.GameCode.GDImpEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects1);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.GameCode.GDSpiderEnemyObjects1);
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects1[i].setZOrder((gdjs.GameCode.GDPlayerObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.GameCode.GDBulletObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDBulletObjects1[i].setZOrder((gdjs.GameCode.GDBulletObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects1[i].setZOrder((gdjs.GameCode.GDGhostEnemyObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.GameCode.GDSpiderEnemyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderEnemyObjects1[i].setZOrder((gdjs.GameCode.GDSpiderEnemyObjects1[i].getPointY("")));
}
for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects1[i].setZOrder((gdjs.GameCode.GDImpEnemyObjects1[i].getPointY("")));
}
}{for(var i = 0, len = gdjs.GameCode.GDGunObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects1[i].setZOrder((( gdjs.GameCode.GDPlayerObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects1[0].getZOrder()) + 1);
}
}{for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects1[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGhostEnemyObjects1Objects, false);
}
for(var i = 0, len = gdjs.GameCode.GDSpiderEnemyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderEnemyObjects1[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSpiderEnemyObjects1Objects, false);
}
for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects1[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDImpEnemyObjects1Objects, false);
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCenterObjects2Objects = Hashtable.newFrom({"Center": gdjs.GameCode.GDCenterObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.GameCode.GDEnemyBulletObjects2});
gdjs.GameCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameCode.GDCenterObjects2 */
/* Reuse gdjs.GameCode.GDImpEnemyObjects2 */
gdjs.GameCode.GDEnemyBulletObjects2.length = 0;

{for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects2[i].getBehavior("FireBullet").FireTowardPosition((gdjs.GameCode.GDImpEnemyObjects2[i].getCenterXInScene()), (gdjs.GameCode.GDImpEnemyObjects2[i].getCenterYInScene()), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEnemyBulletObjects2Objects, (( gdjs.GameCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDCenterObjects2[0].getCenterXInScene()), (( gdjs.GameCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDCenterObjects2[0].getCenterYInScene()), 35, null);
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCenterObjects2Objects = Hashtable.newFrom({"Center": gdjs.GameCode.GDCenterObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSpawnPointsObjects2Objects = Hashtable.newFrom({"SpawnPoints": gdjs.GameCode.GDSpawnPointsObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSpiderSpawnPointsObjects3Objects = Hashtable.newFrom({"SpiderSpawnPoints": gdjs.GameCode.GDSpiderSpawnPointsObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDShadowObjects3Objects = Hashtable.newFrom({"Shadow": gdjs.GameCode.GDShadowObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDDropObjects3Objects = Hashtable.newFrom({"Drop": gdjs.GameCode.GDDropObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSpiderEnemyObjects4Objects = Hashtable.newFrom({"SpiderEnemy": gdjs.GameCode.GDSpiderEnemyObjects4});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHealthBar_95959595EnemyObjects4Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.GameCode.GDHealthBar_9595EnemyObjects4});
gdjs.GameCode.asyncCallback18101620 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.GameCode.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("SpiderSpawnPoints"), gdjs.GameCode.GDSpiderSpawnPointsObjects4);

gdjs.GameCode.GDHealthBar_9595EnemyObjects4.length = 0;

gdjs.GameCode.GDSpiderEnemyObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSpiderEnemyObjects4Objects, (( gdjs.GameCode.GDSpiderSpawnPointsObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDSpiderSpawnPointsObjects4[0].getPointX("")), (( gdjs.GameCode.GDSpiderSpawnPointsObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDSpiderSpawnPointsObjects4[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameCode.GDSpiderEnemyObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderEnemyObjects4[i].getBehavior("Health").SetMaxHealthOp(2 + Math.floor(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() / 3), null);
}
}{for(var i = 0, len = gdjs.GameCode.GDSpiderEnemyObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderEnemyObjects4[i].getBehavior("Health").SetHealth((gdjs.GameCode.GDSpiderEnemyObjects4[i].getBehavior("Health").MaxHealth(null)), null);
}
}{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHealthBar_95959595EnemyObjects4Objects, (( gdjs.GameCode.GDSpiderEnemyObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDSpiderEnemyObjects4[0].getPointX("")), (( gdjs.GameCode.GDSpiderEnemyObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDSpiderEnemyObjects4[0].getPointY("")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.GameCode.GDHealthBar_9595EnemyObjects4.length !== 0 ? gdjs.GameCode.GDHealthBar_9595EnemyObjects4[0] : null), (gdjs.GameCode.GDSpiderEnemyObjects4.length !== 0 ? gdjs.GameCode.GDSpiderEnemyObjects4[0] : null));
}gdjs.GameCode.localVariables.length = 0;
}
gdjs.GameCode.eventsList5 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.GameCode.localVariables);
for (const obj of gdjs.GameCode.GDSpiderSpawnPointsObjects3) asyncObjectsList.addObject("SpiderSpawnPoints", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(1), (runtimeScene) => (gdjs.GameCode.asyncCallback18101620(runtimeScene, asyncObjectsList)));
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGhostEnemyObjects3Objects = Hashtable.newFrom({"GhostEnemy": gdjs.GameCode.GDGhostEnemyObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHealthBar_95959595EnemyObjects3Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.GameCode.GDHealthBar_9595EnemyObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDImpEnemyObjects3Objects = Hashtable.newFrom({"ImpEnemy": gdjs.GameCode.GDImpEnemyObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHealthBar_95959595EnemyObjects3Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.GameCode.GDHealthBar_9595EnemyObjects3});
gdjs.GameCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("SpiderSpawnPoints"), gdjs.GameCode.GDSpiderSpawnPointsObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSpiderSpawnPointsObjects3Objects);
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDSpiderSpawnPointsObjects3 */
gdjs.GameCode.GDDropObjects3.length = 0;

gdjs.GameCode.GDShadowObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDShadowObjects3Objects, (( gdjs.GameCode.GDSpiderSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDSpiderSpawnPointsObjects3[0].getPointX("")), (( gdjs.GameCode.GDSpiderSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDSpiderSpawnPointsObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameCode.GDShadowObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDShadowObjects3[i].getBehavior("Scale").setScale(0);
}
}{for(var i = 0, len = gdjs.GameCode.GDShadowObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDShadowObjects3[i].getBehavior("Tween").addObjectScaleTween("Grow", 1, 1, "linear", 1000, true, false);
}
}{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDDropObjects3Objects, (( gdjs.GameCode.GDSpiderSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDSpiderSpawnPointsObjects3[0].getPointX("")), (( gdjs.GameCode.GDSpiderSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDSpiderSpawnPointsObjects3[0].getPointY("")) - 100, "");
}{for(var i = 0, len = gdjs.GameCode.GDDropObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDropObjects3[i].getBehavior("Tween").addObjectPositionYTween("Drop", (gdjs.GameCode.GDDropObjects3[i].getPointY("")) + 100, "linear", 1000, true);
}
}
{ //Subevents
gdjs.GameCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDSpawnPointsObjects2, gdjs.GameCode.GDSpawnPointsObjects3);

gdjs.GameCode.GDGhostEnemyObjects3.length = 0;

gdjs.GameCode.GDHealthBar_9595EnemyObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGhostEnemyObjects3Objects, (( gdjs.GameCode.GDSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDSpawnPointsObjects3[0].getPointX("")), (( gdjs.GameCode.GDSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDSpawnPointsObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects3[i].getBehavior("Health").SetMaxHealthOp(3 + Math.floor(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() / 3), null);
}
}{for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects3[i].getBehavior("Health").SetHealth((gdjs.GameCode.GDGhostEnemyObjects3[i].getBehavior("Health").MaxHealth(null)), null);
}
}{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHealthBar_95959595EnemyObjects3Objects, (( gdjs.GameCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDGhostEnemyObjects3[0].getPointX("")), (( gdjs.GameCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDGhostEnemyObjects3[0].getPointY("")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.GameCode.GDHealthBar_9595EnemyObjects3.length !== 0 ? gdjs.GameCode.GDHealthBar_9595EnemyObjects3[0] : null), (gdjs.GameCode.GDGhostEnemyObjects3.length !== 0 ? gdjs.GameCode.GDGhostEnemyObjects3[0] : null));
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() == 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDSpawnPointsObjects2, gdjs.GameCode.GDSpawnPointsObjects3);

gdjs.GameCode.GDHealthBar_9595EnemyObjects3.length = 0;

gdjs.GameCode.GDImpEnemyObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDImpEnemyObjects3Objects, (( gdjs.GameCode.GDSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDSpawnPointsObjects3[0].getPointX("")), (( gdjs.GameCode.GDSpawnPointsObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDSpawnPointsObjects3[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects3[i].getBehavior("Health").SetMaxHealthOp(4 + Math.floor(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() / 3), null);
}
}{for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects3[i].getBehavior("Health").SetHealth((gdjs.GameCode.GDImpEnemyObjects3[i].getBehavior("Health").MaxHealth(null)), null);
}
}{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHealthBar_95959595EnemyObjects3Objects, (( gdjs.GameCode.GDImpEnemyObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDImpEnemyObjects3[0].getPointX("")), (( gdjs.GameCode.GDImpEnemyObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDImpEnemyObjects3[0].getPointY("")), "");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.GameCode.GDHealthBar_9595EnemyObjects3.length !== 0 ? gdjs.GameCode.GDHealthBar_9595EnemyObjects3[0] : null), (gdjs.GameCode.GDImpEnemyObjects3.length !== 0 ? gdjs.GameCode.GDImpEnemyObjects3[0] : null));
}}

}


{


let isConditionTrue_0 = false;
{
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Enemy Spawn");
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(gdjs.random(Math.min(Math.floor(runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() / 3), 2)));
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHealthBar_95959595EnemyObjects3Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.GameCode.GDHealthBar_9595EnemyObjects3});
gdjs.GameCode.eventsList7 = function(runtimeScene) {

};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.GameCode.GDBulletObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546GameCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546GameCode_9546GDImpEnemyObjects2Objects = Hashtable.newFrom({"GhostEnemy": gdjs.GameCode.GDGhostEnemyObjects2, "SpiderEnemy": gdjs.GameCode.GDSpiderEnemyObjects2, "ImpEnemy": gdjs.GameCode.GDImpEnemyObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHealthBar_95959595EnemyObjects2Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.GameCode.GDHealthBar_9595EnemyObjects2});
gdjs.GameCode.eventsList8 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDGhostEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("HealthBar_Enemy"), gdjs.GameCode.GDHealthBar_9595EnemyObjects2);
/* Reuse gdjs.GameCode.GDImpEnemyObjects2 */
/* Reuse gdjs.GameCode.GDSpiderEnemyObjects2 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHealthBar_95959595EnemyObjects2Objects, (gdjs.GameCode.GDGhostEnemyObjects2.length !== 0 ? gdjs.GameCode.GDGhostEnemyObjects2[0] : (gdjs.GameCode.GDSpiderEnemyObjects2.length !== 0 ? gdjs.GameCode.GDSpiderEnemyObjects2[0] : (gdjs.GameCode.GDImpEnemyObjects2.length !== 0 ? gdjs.GameCode.GDImpEnemyObjects2[0] : null))), null);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.GameCode.GDHealthBar_9595EnemyObjects2 */
/* Reuse gdjs.GameCode.GDImpEnemyObjects2 */
/* Reuse gdjs.GameCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDHealthBar_9595EnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDHealthBar_9595EnemyObjects2[i].getBehavior("Resizable").setWidth((( gdjs.GameCode.GDImpEnemyObjects2.length === 0 ) ? (( gdjs.GameCode.GDSpiderEnemyObjects2.length === 0 ) ? (( gdjs.GameCode.GDGhostEnemyObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDGhostEnemyObjects2[0].getBehavior("Health").Health(null)) :gdjs.GameCode.GDSpiderEnemyObjects2[0].getBehavior("Health").Health(null)) :gdjs.GameCode.GDImpEnemyObjects2[0].getBehavior("Health").Health(null)) / (( gdjs.GameCode.GDImpEnemyObjects2.length === 0 ) ? (( gdjs.GameCode.GDSpiderEnemyObjects2.length === 0 ) ? (( gdjs.GameCode.GDGhostEnemyObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDGhostEnemyObjects2[0].getBehavior("Health").MaxHealth(null)) :gdjs.GameCode.GDSpiderEnemyObjects2[0].getBehavior("Health").MaxHealth(null)) :gdjs.GameCode.GDImpEnemyObjects2[0].getBehavior("Health").MaxHealth(null)) * 12);
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHealthBar_95959595EnemyObjects2Objects = Hashtable.newFrom({"HealthBar_Enemy": gdjs.GameCode.GDHealthBar_9595EnemyObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEXP_95959595PointObjects1Objects = Hashtable.newFrom({"EXP_Point": gdjs.GameCode.GDEXP_9595PointObjects1});
gdjs.GameCode.eventsList9 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDGhostEnemyObjects1, gdjs.GameCode.GDGhostEnemyObjects2);

gdjs.copyArray(runtimeScene.getObjects("HealthBar_Enemy"), gdjs.GameCode.GDHealthBar_9595EnemyObjects2);
gdjs.copyArray(gdjs.GameCode.GDImpEnemyObjects1, gdjs.GameCode.GDImpEnemyObjects2);

gdjs.copyArray(gdjs.GameCode.GDSpiderEnemyObjects1, gdjs.GameCode.GDSpiderEnemyObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHealthBar_95959595EnemyObjects2Objects, (gdjs.GameCode.GDGhostEnemyObjects2.length !== 0 ? gdjs.GameCode.GDGhostEnemyObjects2[0] : (gdjs.GameCode.GDSpiderEnemyObjects2.length !== 0 ? gdjs.GameCode.GDSpiderEnemyObjects2[0] : (gdjs.GameCode.GDImpEnemyObjects2.length !== 0 ? gdjs.GameCode.GDImpEnemyObjects2[0] : null))), null);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDHealthBar_9595EnemyObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDHealthBar_9595EnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDHealthBar_9595EnemyObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameCode.GDGhostEnemyObjects1 */
/* Reuse gdjs.GameCode.GDImpEnemyObjects1 */
/* Reuse gdjs.GameCode.GDSpiderEnemyObjects1 */
gdjs.GameCode.GDEXP_9595PointObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEXP_95959595PointObjects1Objects, (( gdjs.GameCode.GDImpEnemyObjects1.length === 0 ) ? (( gdjs.GameCode.GDSpiderEnemyObjects1.length === 0 ) ? (( gdjs.GameCode.GDGhostEnemyObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDGhostEnemyObjects1[0].getPointX("")) :gdjs.GameCode.GDSpiderEnemyObjects1[0].getPointX("")) :gdjs.GameCode.GDImpEnemyObjects1[0].getPointX("")), (( gdjs.GameCode.GDImpEnemyObjects1.length === 0 ) ? (( gdjs.GameCode.GDSpiderEnemyObjects1.length === 0 ) ? (( gdjs.GameCode.GDGhostEnemyObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDGhostEnemyObjects1[0].getPointY("")) :gdjs.GameCode.GDSpiderEnemyObjects1[0].getPointY("")) :gdjs.GameCode.GDImpEnemyObjects1[0].getPointY("")), "");
}{for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameCode.GDSpiderEnemyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderEnemyObjects1[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects1[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Enemy Spawn");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Wave");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Wave") > 30;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("WaveNumber"), gdjs.GameCode.GDWaveNumberObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(1).add(1);
}{for(var i = 0, len = gdjs.GameCode.GDWaveNumberObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDWaveNumberObjects2[i].getBehavior("Text").setText("Wave: " + runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "Wave");
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.GameCode.GDImpEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDImpEnemyObjects2[i].getBehavior("Animation").getAnimationName() == "Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDImpEnemyObjects2[k] = gdjs.GameCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDImpEnemyObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.GameCode.GDCenterObjects2);
/* Reuse gdjs.GameCode.GDImpEnemyObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects2[i].getBehavior("BoidsMovement").MoveToObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCenterObjects2Objects, 0.5, null);
}
}
{ //Subevents
gdjs.GameCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.GameCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDSpiderEnemyObjects2[i].getBehavior("Animation").getAnimationName() == "Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSpiderEnemyObjects2[k] = gdjs.GameCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDSpiderEnemyObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.GameCode.GDCenterObjects2);
/* Reuse gdjs.GameCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderEnemyObjects2[i].addForceTowardObject((gdjs.GameCode.GDCenterObjects2.length !== 0 ? gdjs.GameCode.GDCenterObjects2[0] : null), 15, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.GameCode.GDGhostEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDGhostEnemyObjects2[i].getBehavior("Animation").getAnimationName() == "Hurt") ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDGhostEnemyObjects2[k] = gdjs.GameCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDGhostEnemyObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.GameCode.GDCenterObjects2);
/* Reuse gdjs.GameCode.GDGhostEnemyObjects2 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);
{for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects2[i].getBehavior("BoidsMovement").MoveToObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCenterObjects2Objects, 0.5, null);
}
}{for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects2[i].getBehavior("BoidsMovement").AvoidObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects2Objects, 50, 30, null);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.GameCode.GDCenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.GameCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.GameCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.GameCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDGhostEnemyObjects2[i].getX() < (( gdjs.GameCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDGhostEnemyObjects2[k] = gdjs.GameCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDGhostEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDSpiderEnemyObjects2[i].getX() < (( gdjs.GameCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSpiderEnemyObjects2[k] = gdjs.GameCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDSpiderEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDImpEnemyObjects2[i].getX() < (( gdjs.GameCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDImpEnemyObjects2[k] = gdjs.GameCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDImpEnemyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.GameCode.GDImpEnemyObjects2 */
/* Reuse gdjs.GameCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects2[i].getBehavior("Flippable").flipX(false);
}
for(var i = 0, len = gdjs.GameCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderEnemyObjects2[i].getBehavior("Flippable").flipX(false);
}
for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects2[i].getBehavior("Flippable").flipX(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.GameCode.GDCenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.GameCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.GameCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.GameCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDGhostEnemyObjects2[i].getX() >= (( gdjs.GameCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDGhostEnemyObjects2[k] = gdjs.GameCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDGhostEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDSpiderEnemyObjects2[i].getX() >= (( gdjs.GameCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSpiderEnemyObjects2[k] = gdjs.GameCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDSpiderEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDImpEnemyObjects2[i].getX() >= (( gdjs.GameCode.GDCenterObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDCenterObjects2[0].getPointX("")) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDImpEnemyObjects2[k] = gdjs.GameCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDImpEnemyObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.GameCode.GDImpEnemyObjects2 */
/* Reuse gdjs.GameCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects2[i].getBehavior("Flippable").flipX(true);
}
for(var i = 0, len = gdjs.GameCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderEnemyObjects2[i].getBehavior("Flippable").flipX(true);
}
for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects2[i].getBehavior("Flippable").flipX(true);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("SpawnPoints"), gdjs.GameCode.GDSpawnPointsObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "Enemy Spawn") > 3 / runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber();
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickRandomObject(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDSpawnPointsObjects2Objects);
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList6(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.GameCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.GameCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.GameCode.GDSpiderEnemyObjects2);

gdjs.GameCode.forEachTotalCount3 = 0;
gdjs.GameCode.forEachObjects3.length = 0;
gdjs.GameCode.forEachCount0_3 = gdjs.GameCode.GDGhostEnemyObjects2.length;
gdjs.GameCode.forEachTotalCount3 += gdjs.GameCode.forEachCount0_3;
gdjs.GameCode.forEachObjects3.push.apply(gdjs.GameCode.forEachObjects3,gdjs.GameCode.GDGhostEnemyObjects2);
gdjs.GameCode.forEachCount1_3 = gdjs.GameCode.GDSpiderEnemyObjects2.length;
gdjs.GameCode.forEachTotalCount3 += gdjs.GameCode.forEachCount1_3;
gdjs.GameCode.forEachObjects3.push.apply(gdjs.GameCode.forEachObjects3,gdjs.GameCode.GDSpiderEnemyObjects2);
gdjs.GameCode.forEachCount2_3 = gdjs.GameCode.GDImpEnemyObjects2.length;
gdjs.GameCode.forEachTotalCount3 += gdjs.GameCode.forEachCount2_3;
gdjs.GameCode.forEachObjects3.push.apply(gdjs.GameCode.forEachObjects3,gdjs.GameCode.GDImpEnemyObjects2);
for (gdjs.GameCode.forEachIndex3 = 0;gdjs.GameCode.forEachIndex3 < gdjs.GameCode.forEachTotalCount3;++gdjs.GameCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("HealthBar_Enemy"), gdjs.GameCode.GDHealthBar_9595EnemyObjects3);
gdjs.GameCode.GDGhostEnemyObjects3.length = 0;

gdjs.GameCode.GDImpEnemyObjects3.length = 0;

gdjs.GameCode.GDSpiderEnemyObjects3.length = 0;


if (gdjs.GameCode.forEachIndex3 < gdjs.GameCode.forEachCount0_3) {
    gdjs.GameCode.GDGhostEnemyObjects3.push(gdjs.GameCode.forEachObjects3[gdjs.GameCode.forEachIndex3]);
}
else if (gdjs.GameCode.forEachIndex3 < gdjs.GameCode.forEachCount0_3+gdjs.GameCode.forEachCount1_3) {
    gdjs.GameCode.GDSpiderEnemyObjects3.push(gdjs.GameCode.forEachObjects3[gdjs.GameCode.forEachIndex3]);
}
else if (gdjs.GameCode.forEachIndex3 < gdjs.GameCode.forEachCount0_3+gdjs.GameCode.forEachCount1_3+gdjs.GameCode.forEachCount2_3) {
    gdjs.GameCode.GDImpEnemyObjects3.push(gdjs.GameCode.forEachObjects3[gdjs.GameCode.forEachIndex3]);
}
let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHealthBar_95959595EnemyObjects3Objects, (gdjs.GameCode.GDGhostEnemyObjects3.length !== 0 ? gdjs.GameCode.GDGhostEnemyObjects3[0] : (gdjs.GameCode.GDSpiderEnemyObjects3.length !== 0 ? gdjs.GameCode.GDSpiderEnemyObjects3[0] : (gdjs.GameCode.GDImpEnemyObjects3.length !== 0 ? gdjs.GameCode.GDImpEnemyObjects3[0] : null))), null);
if (isConditionTrue_0) {
{for(var i = 0, len = gdjs.GameCode.GDHealthBar_9595EnemyObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDHealthBar_9595EnemyObjects3[i].setPosition((( gdjs.GameCode.GDImpEnemyObjects3.length === 0 ) ? (( gdjs.GameCode.GDSpiderEnemyObjects3.length === 0 ) ? (( gdjs.GameCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDGhostEnemyObjects3[0].getPointX("HealthBar")) :gdjs.GameCode.GDSpiderEnemyObjects3[0].getPointX("HealthBar")) :gdjs.GameCode.GDImpEnemyObjects3[0].getPointX("HealthBar")),(( gdjs.GameCode.GDImpEnemyObjects3.length === 0 ) ? (( gdjs.GameCode.GDSpiderEnemyObjects3.length === 0 ) ? (( gdjs.GameCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDGhostEnemyObjects3[0].getPointY("HealthBar")) :gdjs.GameCode.GDSpiderEnemyObjects3[0].getPointY("HealthBar")) :gdjs.GameCode.GDImpEnemyObjects3[0].getPointY("HealthBar")));
}
}{for(var i = 0, len = gdjs.GameCode.GDHealthBar_9595EnemyObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDHealthBar_9595EnemyObjects3[i].setZOrder((( gdjs.GameCode.GDImpEnemyObjects3.length === 0 ) ? (( gdjs.GameCode.GDSpiderEnemyObjects3.length === 0 ) ? (( gdjs.GameCode.GDGhostEnemyObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDGhostEnemyObjects3[0].getZOrder()) :gdjs.GameCode.GDSpiderEnemyObjects3[0].getZOrder()) :gdjs.GameCode.GDImpEnemyObjects3[0].getZOrder()) + 5);
}
}}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.GameCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.GameCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.GameCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.GameCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBulletObjects2Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546GameCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546GameCode_9546GDImpEnemyObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBulletObjects2 */
/* Reuse gdjs.GameCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.GameCode.GDImpEnemyObjects2 */
/* Reuse gdjs.GameCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects2[i].getBehavior("Health").Hit(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power").getAsNumber(), true, true, null);
}
for(var i = 0, len = gdjs.GameCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderEnemyObjects2[i].getBehavior("Health").Hit(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power").getAsNumber(), true, true, null);
}
for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects2[i].getBehavior("Health").Hit(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power").getAsNumber(), true, true, null);
}
}{for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects2[i].getBehavior("Animation").setAnimationName("Hurt");
}
for(var i = 0, len = gdjs.GameCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderEnemyObjects2[i].getBehavior("Animation").setAnimationName("Hurt");
}
for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects2[i].getBehavior("Animation").setAnimationName("Hurt");
}
}{for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.GameCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderEnemyObjects2[i].setAnimationFrame(0);
}
for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects2[i].setAnimationFrame(0);
}
}
{ //Subevents
gdjs.GameCode.eventsList8(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.GameCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.GameCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.GameCode.GDSpiderEnemyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDGhostEnemyObjects2[i].getBehavior("Animation").getAnimationName() == "Hurt" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDGhostEnemyObjects2[k] = gdjs.GameCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDGhostEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDSpiderEnemyObjects2[i].getBehavior("Animation").getAnimationName() == "Hurt" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSpiderEnemyObjects2[k] = gdjs.GameCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDSpiderEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDImpEnemyObjects2[i].getBehavior("Animation").getAnimationName() == "Hurt" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDImpEnemyObjects2[k] = gdjs.GameCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDImpEnemyObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDGhostEnemyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDGhostEnemyObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDGhostEnemyObjects2[k] = gdjs.GameCode.GDGhostEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDGhostEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSpiderEnemyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDSpiderEnemyObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSpiderEnemyObjects2[k] = gdjs.GameCode.GDSpiderEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDSpiderEnemyObjects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDImpEnemyObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDImpEnemyObjects2[i].getBehavior("Animation").hasAnimationEnded() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDImpEnemyObjects2[k] = gdjs.GameCode.GDImpEnemyObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDImpEnemyObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDGhostEnemyObjects2 */
/* Reuse gdjs.GameCode.GDImpEnemyObjects2 */
/* Reuse gdjs.GameCode.GDSpiderEnemyObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDGhostEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGhostEnemyObjects2[i].getBehavior("Animation").setAnimationName("Walking");
}
for(var i = 0, len = gdjs.GameCode.GDSpiderEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDSpiderEnemyObjects2[i].getBehavior("Animation").setAnimationName("Walking");
}
for(var i = 0, len = gdjs.GameCode.GDImpEnemyObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDImpEnemyObjects2[i].getBehavior("Animation").setAnimationName("Walking");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.GameCode.GDGhostEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.GameCode.GDImpEnemyObjects1);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.GameCode.GDSpiderEnemyObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDGhostEnemyObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDGhostEnemyObjects1[i].getBehavior("Health").IsDead(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDGhostEnemyObjects1[k] = gdjs.GameCode.GDGhostEnemyObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDGhostEnemyObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDSpiderEnemyObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDSpiderEnemyObjects1[i].getBehavior("Health").IsDead(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDSpiderEnemyObjects1[k] = gdjs.GameCode.GDSpiderEnemyObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDSpiderEnemyObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDImpEnemyObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDImpEnemyObjects1[i].getBehavior("Health").IsDead(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDImpEnemyObjects1[k] = gdjs.GameCode.GDImpEnemyObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDImpEnemyObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.GameCode.GDEnemyBulletObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects2});
gdjs.GameCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects4);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDPlayerObjects4[i].getX() < gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects4[k] = gdjs.GameCode.GDPlayerObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects4.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDGunObjects3, gdjs.GameCode.GDGunObjects4);

/* Reuse gdjs.GameCode.GDPlayerObjects4 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects4[i].getBehavior("Flippable").flipX(false);
}
}{for(var i = 0, len = gdjs.GameCode.GDGunObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects4[i].getBehavior("Flippable").flipY(false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDPlayerObjects3[i].getX() > gdjs.evtTools.input.getCursorX(runtimeScene, "", 0) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects3[k] = gdjs.GameCode.GDPlayerObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDGunObjects3 */
/* Reuse gdjs.GameCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects3[i].getBehavior("Flippable").flipX(true);
}
}{for(var i = 0, len = gdjs.GameCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects3[i].getBehavior("Flippable").flipY(true);
}
}}

}


};gdjs.GameCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SpriteMultitouchJoystick__IsDirectionPushed4Way.func(runtimeScene, 1, "Secondary", "Left", null);
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDGunObjects3, gdjs.GameCode.GDGunObjects4);

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects4);
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects4[i].getBehavior("Flippable").flipX(true);
}
}{for(var i = 0, len = gdjs.GameCode.GDGunObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects4[i].getBehavior("Flippable").flipY(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SpriteMultitouchJoystick__IsDirectionPushed4Way.func(runtimeScene, 1, "Secondary", "Right", null);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDGunObjects3 */
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects3[i].getBehavior("Flippable").flipX(false);
}
}{for(var i = 0, len = gdjs.GameCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects3[i].getBehavior("Flippable").flipY(false);
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBulletObjects3Objects = Hashtable.newFrom({"Bullet": gdjs.GameCode.GDBulletObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBulletObjects2Objects = Hashtable.newFrom({"Bullet": gdjs.GameCode.GDBulletObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects2Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects2});
gdjs.GameCode.eventsList13 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameCode.GDGunObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects3);
{for(var i = 0, len = gdjs.GameCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects3[i].setPosition((( gdjs.GameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects3[0].getPointX("Gun")),(( gdjs.GameCode.GDPlayerObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPlayerObjects3[0].getPointY("Gun")));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.systemInfo.isMobile());
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameCode.GDGunObjects3);
{for(var i = 0, len = gdjs.GameCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects3[i].rotateTowardPosition(gdjs.evtTools.input.getCursorX(runtimeScene, "", 0), gdjs.evtTools.input.getCursorY(runtimeScene, "", 0), 0, runtimeScene);
}
}
{ //Subevents
gdjs.GameCode.eventsList11(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.systemInfo.isMobile();
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameCode.GDGunObjects3);
{for(var i = 0, len = gdjs.GameCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects3[i].rotateTowardAngle(gdjs.evtsExt__SpriteMultitouchJoystick__StickAngle.func(runtimeScene, 1, "Secondary", null), 0, runtimeScene);
}
}
{ //Subevents
gdjs.GameCode.eventsList12(runtimeScene);} //End of subevents
}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{let isConditionTrue_2 = false;
isConditionTrue_2 = false;
isConditionTrue_2 = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
if (isConditionTrue_2) {
isConditionTrue_2 = false;
isConditionTrue_2 = !(gdjs.evtTools.systemInfo.isMobile());
}
isConditionTrue_1 = isConditionTrue_2;
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtsExt__SpriteMultitouchJoystick__StickForce.func(runtimeScene, 1, "Secondary", null) > 0;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameCode.GDGunObjects3);
gdjs.GameCode.GDBulletObjects3.length = 0;

{for(var i = 0, len = gdjs.GameCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects3[i].getBehavior("FireBullet").Fire((gdjs.GameCode.GDGunObjects3[i].getPointX("BulletPoint")), (gdjs.GameCode.GDGunObjects3[i].getPointY("BulletPoint")), gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBulletObjects3Objects, (gdjs.GameCode.GDGunObjects3[i].getAngle()), 200, null);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameCode.GDGunObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDGunObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDGunObjects3[i].getBehavior("FireBullet").HasJustFired(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDGunObjects3[k] = gdjs.GameCode.GDGunObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDGunObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDGunObjects3 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Gun", false, runtimeScene.getGame().getVariables().getFromIndex(0).getChild("Sound").getAsNumber(), gdjs.randomFloatInRange(0.8, 1));
}{gdjs.evtsExt__CameraShake__ShakeCamera.func(runtimeScene, 0.1, 0, 0.05, null);
}{for(var i = 0, len = gdjs.GameCode.GDGunObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects3[i].getBehavior("ShakeObject_PositionAngle").ShakeObject_PositionAngle(0.1, 3, 3, 1, 0.05, false, null);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Bullet"), gdjs.GameCode.GDBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBulletObjects2Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects2Objects, 400, true);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBulletObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDBulletObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDWallCollisionObjects2Objects = Hashtable.newFrom({"WallCollision": gdjs.GameCode.GDWallCollisionObjects2});
gdjs.GameCode.eventsList14 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);
gdjs.copyArray(runtimeScene.getObjects("WallCollision"), gdjs.GameCode.GDWallCollisionObjects2);
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDWallCollisionObjects2Objects, false);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPlayerObjects2[i].getBehavior("TopDownMovement").isMoving() ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects2[k] = gdjs.GameCode.GDPlayerObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPlayerObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects2[i].getBehavior("Animation").setAnimationName("Run");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPlayerObjects1.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDPlayerObjects1[i].getBehavior("TopDownMovement").isMoving()) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPlayerObjects1[k] = gdjs.GameCode.GDPlayerObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDPlayerObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDPlayerObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDPlayerObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPlayerObjects1[i].getBehavior("Animation").setAnimationName("Idle");
}
}}

}


};gdjs.GameCode.eventsList15 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.GameCode.GDEnemyBulletObjects2);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEnemyBulletObjects2Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDEnemyBulletObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDEnemyBulletObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDEnemyBulletObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


{


gdjs.GameCode.eventsList13(runtimeScene);
}


{


gdjs.GameCode.eventsList14(runtimeScene);
}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546GameCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546GameCode_9546GDImpEnemyObjects2Objects = Hashtable.newFrom({"GhostEnemy": gdjs.GameCode.GDGhostEnemyObjects2, "SpiderEnemy": gdjs.GameCode.GDSpiderEnemyObjects2, "ImpEnemy": gdjs.GameCode.GDImpEnemyObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCenterObjects2Objects = Hashtable.newFrom({"Center": gdjs.GameCode.GDCenterObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEnemyBulletObjects2Objects = Hashtable.newFrom({"EnemyBullet": gdjs.GameCode.GDEnemyBulletObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCenterObjects2Objects = Hashtable.newFrom({"Center": gdjs.GameCode.GDCenterObjects2});
gdjs.GameCode.eventsList16 = function(runtimeScene) {

{



}


{

gdjs.GameCode.GDCenterObjects1.length = 0;

gdjs.GameCode.GDEnemyBulletObjects1.length = 0;

gdjs.GameCode.GDGhostEnemyObjects1.length = 0;

gdjs.GameCode.GDImpEnemyObjects1.length = 0;

gdjs.GameCode.GDSpiderEnemyObjects1.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.GameCode.GDCenterObjects1_1final.length = 0;
gdjs.GameCode.GDEnemyBulletObjects1_1final.length = 0;
gdjs.GameCode.GDGhostEnemyObjects1_1final.length = 0;
gdjs.GameCode.GDImpEnemyObjects1_1final.length = 0;
gdjs.GameCode.GDSpiderEnemyObjects1_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.GameCode.GDCenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("GhostEnemy"), gdjs.GameCode.GDGhostEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("ImpEnemy"), gdjs.GameCode.GDImpEnemyObjects2);
gdjs.copyArray(runtimeScene.getObjects("SpiderEnemy"), gdjs.GameCode.GDSpiderEnemyObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDGhostEnemyObjects2ObjectsGDgdjs_9546GameCode_9546GDSpiderEnemyObjects2ObjectsGDgdjs_9546GameCode_9546GDImpEnemyObjects2Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCenterObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDCenterObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDCenterObjects1_1final.indexOf(gdjs.GameCode.GDCenterObjects2[j]) === -1 )
            gdjs.GameCode.GDCenterObjects1_1final.push(gdjs.GameCode.GDCenterObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.GameCode.GDGhostEnemyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDGhostEnemyObjects1_1final.indexOf(gdjs.GameCode.GDGhostEnemyObjects2[j]) === -1 )
            gdjs.GameCode.GDGhostEnemyObjects1_1final.push(gdjs.GameCode.GDGhostEnemyObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.GameCode.GDImpEnemyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDImpEnemyObjects1_1final.indexOf(gdjs.GameCode.GDImpEnemyObjects2[j]) === -1 )
            gdjs.GameCode.GDImpEnemyObjects1_1final.push(gdjs.GameCode.GDImpEnemyObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.GameCode.GDSpiderEnemyObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDSpiderEnemyObjects1_1final.indexOf(gdjs.GameCode.GDSpiderEnemyObjects2[j]) === -1 )
            gdjs.GameCode.GDSpiderEnemyObjects1_1final.push(gdjs.GameCode.GDSpiderEnemyObjects2[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Center"), gdjs.GameCode.GDCenterObjects2);
gdjs.copyArray(runtimeScene.getObjects("EnemyBullet"), gdjs.GameCode.GDEnemyBulletObjects2);
isConditionTrue_1 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEnemyBulletObjects2Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDCenterObjects2Objects, false, runtimeScene, false);
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDCenterObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDCenterObjects1_1final.indexOf(gdjs.GameCode.GDCenterObjects2[j]) === -1 )
            gdjs.GameCode.GDCenterObjects1_1final.push(gdjs.GameCode.GDCenterObjects2[j]);
    }
    for (let j = 0, jLen = gdjs.GameCode.GDEnemyBulletObjects2.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDEnemyBulletObjects1_1final.indexOf(gdjs.GameCode.GDEnemyBulletObjects2[j]) === -1 )
            gdjs.GameCode.GDEnemyBulletObjects1_1final.push(gdjs.GameCode.GDEnemyBulletObjects2[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameCode.GDCenterObjects1_1final, gdjs.GameCode.GDCenterObjects1);
gdjs.copyArray(gdjs.GameCode.GDEnemyBulletObjects1_1final, gdjs.GameCode.GDEnemyBulletObjects1);
gdjs.copyArray(gdjs.GameCode.GDGhostEnemyObjects1_1final, gdjs.GameCode.GDGhostEnemyObjects1);
gdjs.copyArray(gdjs.GameCode.GDImpEnemyObjects1_1final, gdjs.GameCode.GDImpEnemyObjects1);
gdjs.copyArray(gdjs.GameCode.GDSpiderEnemyObjects1_1final, gdjs.GameCode.GDSpiderEnemyObjects1);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "MainMenu", false);
}}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEXP_95959595PointObjects3Objects = Hashtable.newFrom({"EXP_Point": gdjs.GameCode.GDEXP_9595PointObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEXP_95959595PointObjects3Objects = Hashtable.newFrom({"EXP_Point": gdjs.GameCode.GDEXP_9595PointObjects3});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects3Objects = Hashtable.newFrom({"Player": gdjs.GameCode.GDPlayerObjects3});
gdjs.GameCode.eventsList17 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Darken"), gdjs.GameCode.GDDarkenObjects3);
{for(var i = 0, len = gdjs.GameCode.GDDarkenObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDDarkenObjects3[i].drawRectangle(0, gdjs.evtTools.camera.getCameraBorderTop(runtimeScene, "LevelUp", 0), gdjs.evtTools.camera.getCameraBorderRight(runtimeScene, "LevelUp", 0), gdjs.evtTools.camera.getCameraBorderBottom(runtimeScene, "LevelUp", 0));
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("EXP_Point"), gdjs.GameCode.GDEXP_9595PointObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEXP_95959595PointObjects3Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects3Objects, 50, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDEXP_9595PointObjects3 */
/* Reuse gdjs.GameCode.GDPlayerObjects3 */
{for(var i = 0, len = gdjs.GameCode.GDEXP_9595PointObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDEXP_9595PointObjects3[i].addForceTowardObject((gdjs.GameCode.GDPlayerObjects3.length !== 0 ? gdjs.GameCode.GDPlayerObjects3[0] : null), 100, 0);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("EXP_Point"), gdjs.GameCode.GDEXP_9595PointObjects3);
gdjs.copyArray(runtimeScene.getObjects("Player"), gdjs.GameCode.GDPlayerObjects3);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.distanceTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDEXP_95959595PointObjects3Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPlayerObjects3Objects, 3, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDEXP_9595PointObjects3 */
gdjs.copyArray(runtimeScene.getObjects("RedFlatBar"), gdjs.GameCode.GDRedFlatBarObjects3);
{for(var i = 0, len = gdjs.GameCode.GDEXP_9595PointObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDEXP_9595PointObjects3[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP").add(1);
}{for(var i = 0, len = gdjs.GameCode.GDRedFlatBarObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDRedFlatBarObjects3[i].SetMaxValue(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP").getAsNumber(), null);
}
}{for(var i = 0, len = gdjs.GameCode.GDRedFlatBarObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDRedFlatBarObjects3[i].SetValue(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP").getAsNumber(), null);
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP").getAsNumber() >= runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP").getAsNumber());
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("RedFlatBar"), gdjs.GameCode.GDRedFlatBarObjects2);
{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 0);
}{gdjs.evtTools.camera.showLayer(runtimeScene, "LevelUp");
}{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP").setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP").setNumber(Math.floor(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP").getAsNumber() * 1.5));
}{for(var i = 0, len = gdjs.GameCode.GDRedFlatBarObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDRedFlatBarObjects2[i].SetValue(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("CurrentEXP").getAsNumber(), null);
}
}{for(var i = 0, len = gdjs.GameCode.GDRedFlatBarObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDRedFlatBarObjects2[i].SetMaxValue(runtimeScene.getScene().getVariables().getFromIndex(0).getChild("MaxEXP").getAsNumber(), null);
}
}}

}


};gdjs.GameCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDPowerButtonObjects1, gdjs.GameCode.GDPowerButtonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPowerButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPowerButtonObjects2[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPowerButtonObjects2[k] = gdjs.GameCode.GDPowerButtonObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPowerButtonObjects2.length = k;
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power").add(1);
}}

}


{

gdjs.copyArray(gdjs.GameCode.GDFireRateButtonObjects1, gdjs.GameCode.GDFireRateButtonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDFireRateButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDFireRateButtonObjects2[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDFireRateButtonObjects2[k] = gdjs.GameCode.GDFireRateButtonObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDFireRateButtonObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameCode.GDGunObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("FireRate").add(1);
}{for(var i = 0, len = gdjs.GameCode.GDGunObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects2[i].getBehavior("FireBullet").SetCooldownOp((gdjs.GameCode.GDGunObjects2[i].getBehavior("FireBullet").Cooldown(null)) * 0.9, null);
}
}}

}


{

gdjs.copyArray(gdjs.GameCode.GDAccuracyButtonObjects1, gdjs.GameCode.GDAccuracyButtonObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDAccuracyButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDAccuracyButtonObjects2[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDAccuracyButtonObjects2[k] = gdjs.GameCode.GDAccuracyButtonObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDAccuracyButtonObjects2.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Gun"), gdjs.GameCode.GDGunObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Accuracy").add(1);
}{for(var i = 0, len = gdjs.GameCode.GDGunObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDGunObjects2[i].getBehavior("FireBullet").SetAngleVarianceOp((gdjs.GameCode.GDGunObjects2[i].getBehavior("FireBullet").AngleVariance(null)) * 0.9, null);
}
}}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("StatsLabel"), gdjs.GameCode.GDStatsLabelObjects1);
{for(var i = 0, len = gdjs.GameCode.GDStatsLabelObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDStatsLabelObjects1[i].getBehavior("Text").setText("Power: " + runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Power").getAsString() + "\nFire Rate: " + runtimeScene.getScene().getVariables().getFromIndex(0).getChild("FireRate").getAsString() + "\nAccuracy: " + runtimeScene.getScene().getVariables().getFromIndex(0).getChild("Accuracy").getAsString());
}
}}

}


};gdjs.GameCode.eventsList19 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("AccuracyButton"), gdjs.GameCode.GDAccuracyButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("FireRateButton"), gdjs.GameCode.GDFireRateButtonObjects1);
gdjs.copyArray(runtimeScene.getObjects("PowerButton"), gdjs.GameCode.GDPowerButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPowerButtonObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDPowerButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPowerButtonObjects1[k] = gdjs.GameCode.GDPowerButtonObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDPowerButtonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDFireRateButtonObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDFireRateButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDFireRateButtonObjects1[k] = gdjs.GameCode.GDFireRateButtonObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDFireRateButtonObjects1.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDAccuracyButtonObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDAccuracyButtonObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDAccuracyButtonObjects1[k] = gdjs.GameCode.GDAccuracyButtonObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDAccuracyButtonObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "LevelUp");
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "LevelUp");
}{gdjs.evtTools.runtimeScene.setTimeScale(runtimeScene, 1);
}
{ //Subevents
gdjs.GameCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList20 = function(runtimeScene) {

{


gdjs.GameCode.eventsList17(runtimeScene);
}


{


gdjs.GameCode.eventsList19(runtimeScene);
}


};gdjs.GameCode.eventsList21 = function(runtimeScene) {

{


gdjs.GameCode.eventsList2(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Movement"), gdjs.GameCode.GDMovementObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SpriteMultitouchJoystick__HasTouchStartedOnScreenSide.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMovementObjects1Objects, "Left", null);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDMovementObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDMovementObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMovementObjects1[i].TeleportAndPress(null);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Movement"), gdjs.GameCode.GDMovementObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtsExt__SpriteMultitouchJoystick__HasTouchStartedOnScreenSide.func(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDMovementObjects1Objects, "Right", null);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Aiming"), gdjs.GameCode.GDAimingObjects1);
{for(var i = 0, len = gdjs.GameCode.GDAimingObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDAimingObjects1[i].TeleportAndPress(null);
}
}}

}


{


gdjs.GameCode.eventsList3(runtimeScene);
}


{


gdjs.GameCode.eventsList10(runtimeScene);
}


{


gdjs.GameCode.eventsList15(runtimeScene);
}


{


gdjs.GameCode.eventsList16(runtimeScene);
}


{


gdjs.GameCode.eventsList20(runtimeScene);
}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDFloorObjects1.length = 0;
gdjs.GameCode.GDFloorObjects2.length = 0;
gdjs.GameCode.GDFloorObjects3.length = 0;
gdjs.GameCode.GDFloorObjects4.length = 0;
gdjs.GameCode.GDFloorObjects5.length = 0;
gdjs.GameCode.GDPlayerObjects1.length = 0;
gdjs.GameCode.GDPlayerObjects2.length = 0;
gdjs.GameCode.GDPlayerObjects3.length = 0;
gdjs.GameCode.GDPlayerObjects4.length = 0;
gdjs.GameCode.GDPlayerObjects5.length = 0;
gdjs.GameCode.GDGunObjects1.length = 0;
gdjs.GameCode.GDGunObjects2.length = 0;
gdjs.GameCode.GDGunObjects3.length = 0;
gdjs.GameCode.GDGunObjects4.length = 0;
gdjs.GameCode.GDGunObjects5.length = 0;
gdjs.GameCode.GDBulletObjects1.length = 0;
gdjs.GameCode.GDBulletObjects2.length = 0;
gdjs.GameCode.GDBulletObjects3.length = 0;
gdjs.GameCode.GDBulletObjects4.length = 0;
gdjs.GameCode.GDBulletObjects5.length = 0;
gdjs.GameCode.GDGhostEnemyObjects1.length = 0;
gdjs.GameCode.GDGhostEnemyObjects2.length = 0;
gdjs.GameCode.GDGhostEnemyObjects3.length = 0;
gdjs.GameCode.GDGhostEnemyObjects4.length = 0;
gdjs.GameCode.GDGhostEnemyObjects5.length = 0;
gdjs.GameCode.GDSpiderEnemyObjects1.length = 0;
gdjs.GameCode.GDSpiderEnemyObjects2.length = 0;
gdjs.GameCode.GDSpiderEnemyObjects3.length = 0;
gdjs.GameCode.GDSpiderEnemyObjects4.length = 0;
gdjs.GameCode.GDSpiderEnemyObjects5.length = 0;
gdjs.GameCode.GDImpEnemyObjects1.length = 0;
gdjs.GameCode.GDImpEnemyObjects2.length = 0;
gdjs.GameCode.GDImpEnemyObjects3.length = 0;
gdjs.GameCode.GDImpEnemyObjects4.length = 0;
gdjs.GameCode.GDImpEnemyObjects5.length = 0;
gdjs.GameCode.GDCenterObjects1.length = 0;
gdjs.GameCode.GDCenterObjects2.length = 0;
gdjs.GameCode.GDCenterObjects3.length = 0;
gdjs.GameCode.GDCenterObjects4.length = 0;
gdjs.GameCode.GDCenterObjects5.length = 0;
gdjs.GameCode.GDSpawnPointsObjects1.length = 0;
gdjs.GameCode.GDSpawnPointsObjects2.length = 0;
gdjs.GameCode.GDSpawnPointsObjects3.length = 0;
gdjs.GameCode.GDSpawnPointsObjects4.length = 0;
gdjs.GameCode.GDSpawnPointsObjects5.length = 0;
gdjs.GameCode.GDSpiderSpawnPointsObjects1.length = 0;
gdjs.GameCode.GDSpiderSpawnPointsObjects2.length = 0;
gdjs.GameCode.GDSpiderSpawnPointsObjects3.length = 0;
gdjs.GameCode.GDSpiderSpawnPointsObjects4.length = 0;
gdjs.GameCode.GDSpiderSpawnPointsObjects5.length = 0;
gdjs.GameCode.GDHealthBar_9595EnemyObjects1.length = 0;
gdjs.GameCode.GDHealthBar_9595EnemyObjects2.length = 0;
gdjs.GameCode.GDHealthBar_9595EnemyObjects3.length = 0;
gdjs.GameCode.GDHealthBar_9595EnemyObjects4.length = 0;
gdjs.GameCode.GDHealthBar_9595EnemyObjects5.length = 0;
gdjs.GameCode.GDWallCollisionObjects1.length = 0;
gdjs.GameCode.GDWallCollisionObjects2.length = 0;
gdjs.GameCode.GDWallCollisionObjects3.length = 0;
gdjs.GameCode.GDWallCollisionObjects4.length = 0;
gdjs.GameCode.GDWallCollisionObjects5.length = 0;
gdjs.GameCode.GDvignetteObjects1.length = 0;
gdjs.GameCode.GDvignetteObjects2.length = 0;
gdjs.GameCode.GDvignetteObjects3.length = 0;
gdjs.GameCode.GDvignetteObjects4.length = 0;
gdjs.GameCode.GDvignetteObjects5.length = 0;
gdjs.GameCode.GDRedFlatBarObjects1.length = 0;
gdjs.GameCode.GDRedFlatBarObjects2.length = 0;
gdjs.GameCode.GDRedFlatBarObjects3.length = 0;
gdjs.GameCode.GDRedFlatBarObjects4.length = 0;
gdjs.GameCode.GDRedFlatBarObjects5.length = 0;
gdjs.GameCode.GDEXP_9595PointObjects1.length = 0;
gdjs.GameCode.GDEXP_9595PointObjects2.length = 0;
gdjs.GameCode.GDEXP_9595PointObjects3.length = 0;
gdjs.GameCode.GDEXP_9595PointObjects4.length = 0;
gdjs.GameCode.GDEXP_9595PointObjects5.length = 0;
gdjs.GameCode.GDStatsLabelObjects1.length = 0;
gdjs.GameCode.GDStatsLabelObjects2.length = 0;
gdjs.GameCode.GDStatsLabelObjects3.length = 0;
gdjs.GameCode.GDStatsLabelObjects4.length = 0;
gdjs.GameCode.GDStatsLabelObjects5.length = 0;
gdjs.GameCode.GDPowerButtonObjects1.length = 0;
gdjs.GameCode.GDPowerButtonObjects2.length = 0;
gdjs.GameCode.GDPowerButtonObjects3.length = 0;
gdjs.GameCode.GDPowerButtonObjects4.length = 0;
gdjs.GameCode.GDPowerButtonObjects5.length = 0;
gdjs.GameCode.GDFireRateButtonObjects1.length = 0;
gdjs.GameCode.GDFireRateButtonObjects2.length = 0;
gdjs.GameCode.GDFireRateButtonObjects3.length = 0;
gdjs.GameCode.GDFireRateButtonObjects4.length = 0;
gdjs.GameCode.GDFireRateButtonObjects5.length = 0;
gdjs.GameCode.GDAccuracyButtonObjects1.length = 0;
gdjs.GameCode.GDAccuracyButtonObjects2.length = 0;
gdjs.GameCode.GDAccuracyButtonObjects3.length = 0;
gdjs.GameCode.GDAccuracyButtonObjects4.length = 0;
gdjs.GameCode.GDAccuracyButtonObjects5.length = 0;
gdjs.GameCode.GDWaveNumberObjects1.length = 0;
gdjs.GameCode.GDWaveNumberObjects2.length = 0;
gdjs.GameCode.GDWaveNumberObjects3.length = 0;
gdjs.GameCode.GDWaveNumberObjects4.length = 0;
gdjs.GameCode.GDWaveNumberObjects5.length = 0;
gdjs.GameCode.GDEnemyBulletObjects1.length = 0;
gdjs.GameCode.GDEnemyBulletObjects2.length = 0;
gdjs.GameCode.GDEnemyBulletObjects3.length = 0;
gdjs.GameCode.GDEnemyBulletObjects4.length = 0;
gdjs.GameCode.GDEnemyBulletObjects5.length = 0;
gdjs.GameCode.GDShadowObjects1.length = 0;
gdjs.GameCode.GDShadowObjects2.length = 0;
gdjs.GameCode.GDShadowObjects3.length = 0;
gdjs.GameCode.GDShadowObjects4.length = 0;
gdjs.GameCode.GDShadowObjects5.length = 0;
gdjs.GameCode.GDDropObjects1.length = 0;
gdjs.GameCode.GDDropObjects2.length = 0;
gdjs.GameCode.GDDropObjects3.length = 0;
gdjs.GameCode.GDDropObjects4.length = 0;
gdjs.GameCode.GDDropObjects5.length = 0;
gdjs.GameCode.GDMovementObjects1.length = 0;
gdjs.GameCode.GDMovementObjects2.length = 0;
gdjs.GameCode.GDMovementObjects3.length = 0;
gdjs.GameCode.GDMovementObjects4.length = 0;
gdjs.GameCode.GDMovementObjects5.length = 0;
gdjs.GameCode.GDAimingObjects1.length = 0;
gdjs.GameCode.GDAimingObjects2.length = 0;
gdjs.GameCode.GDAimingObjects3.length = 0;
gdjs.GameCode.GDAimingObjects4.length = 0;
gdjs.GameCode.GDAimingObjects5.length = 0;
gdjs.GameCode.GDScreenOrientationCheckerObjects1.length = 0;
gdjs.GameCode.GDScreenOrientationCheckerObjects2.length = 0;
gdjs.GameCode.GDScreenOrientationCheckerObjects3.length = 0;
gdjs.GameCode.GDScreenOrientationCheckerObjects4.length = 0;
gdjs.GameCode.GDScreenOrientationCheckerObjects5.length = 0;
gdjs.GameCode.GDTransitionObjects1.length = 0;
gdjs.GameCode.GDTransitionObjects2.length = 0;
gdjs.GameCode.GDTransitionObjects3.length = 0;
gdjs.GameCode.GDTransitionObjects4.length = 0;
gdjs.GameCode.GDTransitionObjects5.length = 0;
gdjs.GameCode.GDDarkenObjects1.length = 0;
gdjs.GameCode.GDDarkenObjects2.length = 0;
gdjs.GameCode.GDDarkenObjects3.length = 0;
gdjs.GameCode.GDDarkenObjects4.length = 0;
gdjs.GameCode.GDDarkenObjects5.length = 0;

gdjs.GameCode.eventsList21(runtimeScene);
gdjs.GameCode.GDFloorObjects1.length = 0;
gdjs.GameCode.GDFloorObjects2.length = 0;
gdjs.GameCode.GDFloorObjects3.length = 0;
gdjs.GameCode.GDFloorObjects4.length = 0;
gdjs.GameCode.GDFloorObjects5.length = 0;
gdjs.GameCode.GDPlayerObjects1.length = 0;
gdjs.GameCode.GDPlayerObjects2.length = 0;
gdjs.GameCode.GDPlayerObjects3.length = 0;
gdjs.GameCode.GDPlayerObjects4.length = 0;
gdjs.GameCode.GDPlayerObjects5.length = 0;
gdjs.GameCode.GDGunObjects1.length = 0;
gdjs.GameCode.GDGunObjects2.length = 0;
gdjs.GameCode.GDGunObjects3.length = 0;
gdjs.GameCode.GDGunObjects4.length = 0;
gdjs.GameCode.GDGunObjects5.length = 0;
gdjs.GameCode.GDBulletObjects1.length = 0;
gdjs.GameCode.GDBulletObjects2.length = 0;
gdjs.GameCode.GDBulletObjects3.length = 0;
gdjs.GameCode.GDBulletObjects4.length = 0;
gdjs.GameCode.GDBulletObjects5.length = 0;
gdjs.GameCode.GDGhostEnemyObjects1.length = 0;
gdjs.GameCode.GDGhostEnemyObjects2.length = 0;
gdjs.GameCode.GDGhostEnemyObjects3.length = 0;
gdjs.GameCode.GDGhostEnemyObjects4.length = 0;
gdjs.GameCode.GDGhostEnemyObjects5.length = 0;
gdjs.GameCode.GDSpiderEnemyObjects1.length = 0;
gdjs.GameCode.GDSpiderEnemyObjects2.length = 0;
gdjs.GameCode.GDSpiderEnemyObjects3.length = 0;
gdjs.GameCode.GDSpiderEnemyObjects4.length = 0;
gdjs.GameCode.GDSpiderEnemyObjects5.length = 0;
gdjs.GameCode.GDImpEnemyObjects1.length = 0;
gdjs.GameCode.GDImpEnemyObjects2.length = 0;
gdjs.GameCode.GDImpEnemyObjects3.length = 0;
gdjs.GameCode.GDImpEnemyObjects4.length = 0;
gdjs.GameCode.GDImpEnemyObjects5.length = 0;
gdjs.GameCode.GDCenterObjects1.length = 0;
gdjs.GameCode.GDCenterObjects2.length = 0;
gdjs.GameCode.GDCenterObjects3.length = 0;
gdjs.GameCode.GDCenterObjects4.length = 0;
gdjs.GameCode.GDCenterObjects5.length = 0;
gdjs.GameCode.GDSpawnPointsObjects1.length = 0;
gdjs.GameCode.GDSpawnPointsObjects2.length = 0;
gdjs.GameCode.GDSpawnPointsObjects3.length = 0;
gdjs.GameCode.GDSpawnPointsObjects4.length = 0;
gdjs.GameCode.GDSpawnPointsObjects5.length = 0;
gdjs.GameCode.GDSpiderSpawnPointsObjects1.length = 0;
gdjs.GameCode.GDSpiderSpawnPointsObjects2.length = 0;
gdjs.GameCode.GDSpiderSpawnPointsObjects3.length = 0;
gdjs.GameCode.GDSpiderSpawnPointsObjects4.length = 0;
gdjs.GameCode.GDSpiderSpawnPointsObjects5.length = 0;
gdjs.GameCode.GDHealthBar_9595EnemyObjects1.length = 0;
gdjs.GameCode.GDHealthBar_9595EnemyObjects2.length = 0;
gdjs.GameCode.GDHealthBar_9595EnemyObjects3.length = 0;
gdjs.GameCode.GDHealthBar_9595EnemyObjects4.length = 0;
gdjs.GameCode.GDHealthBar_9595EnemyObjects5.length = 0;
gdjs.GameCode.GDWallCollisionObjects1.length = 0;
gdjs.GameCode.GDWallCollisionObjects2.length = 0;
gdjs.GameCode.GDWallCollisionObjects3.length = 0;
gdjs.GameCode.GDWallCollisionObjects4.length = 0;
gdjs.GameCode.GDWallCollisionObjects5.length = 0;
gdjs.GameCode.GDvignetteObjects1.length = 0;
gdjs.GameCode.GDvignetteObjects2.length = 0;
gdjs.GameCode.GDvignetteObjects3.length = 0;
gdjs.GameCode.GDvignetteObjects4.length = 0;
gdjs.GameCode.GDvignetteObjects5.length = 0;
gdjs.GameCode.GDRedFlatBarObjects1.length = 0;
gdjs.GameCode.GDRedFlatBarObjects2.length = 0;
gdjs.GameCode.GDRedFlatBarObjects3.length = 0;
gdjs.GameCode.GDRedFlatBarObjects4.length = 0;
gdjs.GameCode.GDRedFlatBarObjects5.length = 0;
gdjs.GameCode.GDEXP_9595PointObjects1.length = 0;
gdjs.GameCode.GDEXP_9595PointObjects2.length = 0;
gdjs.GameCode.GDEXP_9595PointObjects3.length = 0;
gdjs.GameCode.GDEXP_9595PointObjects4.length = 0;
gdjs.GameCode.GDEXP_9595PointObjects5.length = 0;
gdjs.GameCode.GDStatsLabelObjects1.length = 0;
gdjs.GameCode.GDStatsLabelObjects2.length = 0;
gdjs.GameCode.GDStatsLabelObjects3.length = 0;
gdjs.GameCode.GDStatsLabelObjects4.length = 0;
gdjs.GameCode.GDStatsLabelObjects5.length = 0;
gdjs.GameCode.GDPowerButtonObjects1.length = 0;
gdjs.GameCode.GDPowerButtonObjects2.length = 0;
gdjs.GameCode.GDPowerButtonObjects3.length = 0;
gdjs.GameCode.GDPowerButtonObjects4.length = 0;
gdjs.GameCode.GDPowerButtonObjects5.length = 0;
gdjs.GameCode.GDFireRateButtonObjects1.length = 0;
gdjs.GameCode.GDFireRateButtonObjects2.length = 0;
gdjs.GameCode.GDFireRateButtonObjects3.length = 0;
gdjs.GameCode.GDFireRateButtonObjects4.length = 0;
gdjs.GameCode.GDFireRateButtonObjects5.length = 0;
gdjs.GameCode.GDAccuracyButtonObjects1.length = 0;
gdjs.GameCode.GDAccuracyButtonObjects2.length = 0;
gdjs.GameCode.GDAccuracyButtonObjects3.length = 0;
gdjs.GameCode.GDAccuracyButtonObjects4.length = 0;
gdjs.GameCode.GDAccuracyButtonObjects5.length = 0;
gdjs.GameCode.GDWaveNumberObjects1.length = 0;
gdjs.GameCode.GDWaveNumberObjects2.length = 0;
gdjs.GameCode.GDWaveNumberObjects3.length = 0;
gdjs.GameCode.GDWaveNumberObjects4.length = 0;
gdjs.GameCode.GDWaveNumberObjects5.length = 0;
gdjs.GameCode.GDEnemyBulletObjects1.length = 0;
gdjs.GameCode.GDEnemyBulletObjects2.length = 0;
gdjs.GameCode.GDEnemyBulletObjects3.length = 0;
gdjs.GameCode.GDEnemyBulletObjects4.length = 0;
gdjs.GameCode.GDEnemyBulletObjects5.length = 0;
gdjs.GameCode.GDShadowObjects1.length = 0;
gdjs.GameCode.GDShadowObjects2.length = 0;
gdjs.GameCode.GDShadowObjects3.length = 0;
gdjs.GameCode.GDShadowObjects4.length = 0;
gdjs.GameCode.GDShadowObjects5.length = 0;
gdjs.GameCode.GDDropObjects1.length = 0;
gdjs.GameCode.GDDropObjects2.length = 0;
gdjs.GameCode.GDDropObjects3.length = 0;
gdjs.GameCode.GDDropObjects4.length = 0;
gdjs.GameCode.GDDropObjects5.length = 0;
gdjs.GameCode.GDMovementObjects1.length = 0;
gdjs.GameCode.GDMovementObjects2.length = 0;
gdjs.GameCode.GDMovementObjects3.length = 0;
gdjs.GameCode.GDMovementObjects4.length = 0;
gdjs.GameCode.GDMovementObjects5.length = 0;
gdjs.GameCode.GDAimingObjects1.length = 0;
gdjs.GameCode.GDAimingObjects2.length = 0;
gdjs.GameCode.GDAimingObjects3.length = 0;
gdjs.GameCode.GDAimingObjects4.length = 0;
gdjs.GameCode.GDAimingObjects5.length = 0;
gdjs.GameCode.GDScreenOrientationCheckerObjects1.length = 0;
gdjs.GameCode.GDScreenOrientationCheckerObjects2.length = 0;
gdjs.GameCode.GDScreenOrientationCheckerObjects3.length = 0;
gdjs.GameCode.GDScreenOrientationCheckerObjects4.length = 0;
gdjs.GameCode.GDScreenOrientationCheckerObjects5.length = 0;
gdjs.GameCode.GDTransitionObjects1.length = 0;
gdjs.GameCode.GDTransitionObjects2.length = 0;
gdjs.GameCode.GDTransitionObjects3.length = 0;
gdjs.GameCode.GDTransitionObjects4.length = 0;
gdjs.GameCode.GDTransitionObjects5.length = 0;
gdjs.GameCode.GDDarkenObjects1.length = 0;
gdjs.GameCode.GDDarkenObjects2.length = 0;
gdjs.GameCode.GDDarkenObjects3.length = 0;
gdjs.GameCode.GDDarkenObjects4.length = 0;
gdjs.GameCode.GDDarkenObjects5.length = 0;


return;

}

gdjs['GameCode'] = gdjs.GameCode;
